;(function(){
	window.viewJsNewestVersion = "1.5.0-B201709061010";
	window.viewJsNewestZipFile = "dist/viewjs-1.5.0-B201709061010.zip";
})();