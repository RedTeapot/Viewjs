;(function(){
	window.viewJsNewestVersion = "1.5.1-B201801251344";
	window.viewJsNewestZipFile = "dist/viewjs-1.5.1-B201801251344.zip";
})();