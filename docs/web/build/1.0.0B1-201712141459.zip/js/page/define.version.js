;(function(){
	window.viewJsNewestVersion = "1.5.1-B201712141454";
	window.viewJsNewestZipFile = "dist/viewjs-1.5.1-B201712141454.zip";
})();