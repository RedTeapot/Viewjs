;(function(){
	window.viewJsNewestVersion = "1.5.1-B201712141341";
	window.viewJsNewestZipFile = "dist/viewjs-1.5.1-B201712141341.zip";
})();