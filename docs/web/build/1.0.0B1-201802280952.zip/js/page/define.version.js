;(function(){
	window.viewJsNewestVersion = "1.5.2-B201802081353";
	window.viewJsNewestZipFile = "dist/viewjs-1.5.2-B201802081353.zip";
})();